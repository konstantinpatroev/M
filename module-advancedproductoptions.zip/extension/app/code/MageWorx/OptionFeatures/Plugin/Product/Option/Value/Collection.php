<?php
/**
 * Copyright © 2017 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\OptionFeatures\Plugin\Product\Option\Value;

use MageWorx\OptionFeatures\Model\OptionTypeDescription;
use MageWorx\OptionFeatures\Model\Image;
use Magento\Catalog\Model\ResourceModel\Product\Option\Value\Collection as ValueCollection;
use Magento\Framework\App\ResourceConnection;

class Collection
{
    /**
     * @var ResourceConnection
     */
    protected $resource;

    /**
     * @param ResourceConnection $resource
     */
    public function __construct(
        ResourceConnection $resource
    ) {
        $this->resource = $resource;
    }

    /**
     * @param ValueCollection $subject
     * @param bool $printQuery
     * @param bool $logQuery
     * @return array
     */
    public function beforeLoad($subject, $printQuery = false, $logQuery = false)
    {
        $this->addDescriptionToResult($subject);
        $this->addImagesToResult($subject);

        return [$printQuery, $logQuery];
    }

    /**
     * Add images to result
     *
     * @param ValueCollection $collection
     * @return ValueCollection $collection
     */
    private function addImagesToResult(ValueCollection $collection)
    {
        $from = $collection->getSelect()->getPart('from');
        if (isset($from['option_value_base_image']) || isset($from['option_value_tooltip_image'])) {
            // Do nothing if tables already has been joined
            return $collection;
        }

        $tableName = $this->resource->getTableName(Image::TABLE_NAME);
        if ($from['main_table']['tableName'] == $this->resource->getTableName('mageworx_optiontemplates_group_option_type_value')) {
            $tableName = $this->resource->getTableName(Image::OPTIONTEMPLATES_TABLE_NAME);
        }

        $joinBaseImageExpr = 'main_table.mageworx_option_type_id = option_value_base_image.mageworx_option_type_id';
        $joinBaseImageExpr .= ' AND option_value_base_image.base_image = "1"';

        $joinTooltipImageExpr = 'main_table.mageworx_option_type_id = option_value_tooltip_image.mageworx_option_type_id';
        $joinTooltipImageExpr .= ' AND option_value_tooltip_image.tooltip_image = "1"';

        //extend for export/import
        $selectImagesExpr = "SELECT mageworx_option_type_id,";
        $selectImagesExpr .= " concat('[',";
        $selectImagesExpr .= " group_concat(concat(";
        $selectImagesExpr .= "'{\"value\"',':\"',IFNULL(value,''),'\",',";
        $selectImagesExpr .= "'\"option_type_image_id\"',':\"',option_type_image_id,'\",',";
        $selectImagesExpr .= "'\"title_text\"',':\"',IFNULL(title_text,''),'\",',";
        $selectImagesExpr .= "'\"sort_order\"',':\"',sort_order,'\",',";
        $selectImagesExpr .= "'\"base_image\"',':\"',base_image,'\",',";
        $selectImagesExpr .= "'\"replace_main_gallery_image\"',':\"',IFNULL(replace_main_gallery_image,''),'\",',";
        $selectImagesExpr .= "'\"custom_media_type\"',':\"',media_type,'\",',";
        $selectImagesExpr .= "'\"color\"',':\"',IFNULL(color,''),'\",',";
        $selectImagesExpr .= "'\"disabled\"',':\"',disabled,'\",',";
        $selectImagesExpr .= "'\"tooltip_image\"',':\"',tooltip_image,'\"}'";
        $selectImagesExpr .= ")),";
        $selectImagesExpr .= "']')";
        $selectImagesExpr .= " AS images_data FROM " . $tableName . " GROUP BY mageworx_option_type_id";

        $joinImagesExpr = 'main_table.mageworx_option_type_id = option_value_images.mageworx_option_type_id';

        $collection->getSelect()->joinLeft(
            ['option_value_base_image' => $tableName],
            $joinBaseImageExpr,
            ['base_image' => 'value', 'base_image_type' => 'media_type']
        )->joinLeft(
            ['option_value_tooltip_image' => $tableName],
            $joinTooltipImageExpr,
            ['tooltip_image' => 'value', 'tooltip_image_type' => 'media_type']
        )->joinLeft(
            ['option_value_images' => new \Zend_Db_Expr('(' . $selectImagesExpr . ')')],
            $joinImagesExpr,
            ['images_data' => 'images_data']
        );

        return $collection;
    }

    /**
     * Add images to result
     *
     * @param ValueCollection $collection
     * @return $collection
     */
    private function addDescriptionToResult($collection)
    {
        $from = $collection->getSelect()->getPart('from');
        if (isset($from['option_type_description'])) {
            // Do nothing if tables already has been joined
            return $collection;
        }

        $tableName = $this->resource->getTableName(OptionTypeDescription::TABLE_NAME);
        if ($from['main_table']['tableName'] == $this->resource->getTableName('mageworx_optiontemplates_group_option_type_value')) {
            $tableName = $this->resource->getTableName(OptionTypeDescription::OPTIONTEMPLATES_TABLE_NAME);
        }

        $joinDescriptionExpr = 'main_table.mageworx_option_type_id = option_type_description.mageworx_option_type_id';

        $collection->getSelect()->joinLeft(
            ['option_type_description' => $tableName],
            $joinDescriptionExpr,
            ['description' => 'description']
        );

        return $collection;
    }
}
