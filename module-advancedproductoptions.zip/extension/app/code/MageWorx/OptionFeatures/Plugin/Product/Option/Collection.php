<?php
/**
 * Copyright © 2017 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\OptionFeatures\Plugin\Product\Option;

use MageWorx\OptionFeatures\Model\OptionDescription;
use Magento\Catalog\Model\ResourceModel\Product\Option\Collection as OptionCollection;
use MageWorx\OptionFeatures\Helper\Data as Helper;
use Magento\Framework\App\ResourceConnection;

class Collection
{
    /**
     * @var ResourceConnection
     */
    protected $resource;

    /**
     * @var Helper
     */
    protected $helper;

    /**
     * @param ResourceConnection $resource
     * @param Helper $helper
     */
    public function __construct(
        ResourceConnection $resource,
        Helper $helper
    ) {
        $this->resource = $resource;
        $this->helper = $helper;
    }

    /**
     * @param OptionCollection $subject
     * @param bool $printQuery
     * @param bool $logQuery
     * @return array
     */
    public function beforeLoad($subject, $printQuery = false, $logQuery = false)
    {
        $this->addDescriptionToResult($subject);

        return [$printQuery, $logQuery];
    }

    /**
     * Add description to result
     *
     * @param OptionCollection $collection
     * @return OptionCollection $collection
     */
    private function addDescriptionToResult($collection)
    {
        $from = $collection->getSelect()->getPart('from');
        if (isset($from['option_description'])) {
            // Do nothing if tables already has been joined
            return $collection;
        }
        $tableName = $this->resource->getTableName(OptionDescription::TABLE_NAME);
        if ($from['main_table']['tableName'] == $this->resource->getTableName('mageworx_optiontemplates_group_option')) {
            $tableName = $this->resource->getTableName(OptionDescription::OPTIONTEMPLATES_TABLE_NAME);
        }

        $joinDescriptionExpr =
            'main_table.mageworx_option_id = option_description.mageworx_option_id';

        $collection->getSelect()->joinLeft(
            ['option_description' => $tableName],
            $joinDescriptionExpr,
            ['description' => 'description']
        );

        return $collection;
    }

    /**
     * Resolve current store id
     *
     * @return int
     */
    protected function getStoreId()
    {
        return $this->helper->resolveCurrentStoreId();
    }
}
