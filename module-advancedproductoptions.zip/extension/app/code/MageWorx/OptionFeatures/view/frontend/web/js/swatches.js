/**
 * Copyright © 2017 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
define(
    [
        'jquery',
        'underscore',
        'mage/translate',
        'Magento_Catalog/js/price-utils',
        'jquery/validate',
        'jquery/ui',
        'jquery/jquery.parsequery'
    ],
    function ($, _, $t, priceUtils) {
        'use strict';

        $.widget('mage.mageworxOptionSwatch', {
            params: {
                classes: {
                    optionClass: 'mageworx-swatch-option'
                }
            },

            init: function (params) {
                this.params = this._mergeParams(this.params, params);
                this._initParams(params);
                this._initActions();
                this._observeStyleOptions();
            },

            _initParams: function (params) {
                var self = this;
                params = params || {};
                $.each(params, function (i, e) {
                    self.params[i] = e;
                });
            },

            _mergeParams: function (params1, params2) {
                $.each(params2, function (i, e) {
                    params1[i] = e;
                });
                return params1;
            },

            _initActions: function () {
                var self = this;

                // Handle events like click or change
                this._initEventListener();
            },

            _observeStyleOptions: function () {
                var self = this;
                var target = $('.' + this.params.classes.optionClass).next('select').find('option');
                var observer = new MutationObserver(function (mutations) {
                    mutations.forEach(function (mutationRecord) {
                        self._toggleSwatch($(mutationRecord.target));
                    });
                });

                $.each(target, function (i, e) {
                    observer.observe(e, {attributes: true, attributeFilter: ['style']});
                });
            },

            _toggleSwatch: function (value) {
                var swatch = $('[option-type-id="' + value.val() + '"]');

                swatch.css('display', value.css('display'));
            },


            /**
             * Event listener
             */
            _initEventListener: function () {
                var self = this;

                $('body').on('click', '.' + this.params.classes.optionClass, function () {
                    self._onClick(this);
                });
            },

            _onClick: function (option) {
                if ($(option).hasClass('disabled')) {
                    return;
                }

                var optionId = $(option).attr('option-id');
                var optionValueId = $(option).attr('option-type-id');
                var select = $('#select_' + optionId);
                var selectOptions = $('#select_' + optionId + ' option');
                if (!selectOptions) {
                    return;
                }

                if ($(option).parents('.field').find('label').parent().find('span#value').length <= 0) {
                    $(option).parents('.field').find('label').after('<span id="value"></span>');
                }
                $(selectOptions).each(function () {
                    if ($(this).val() == optionValueId) {
                        if ($(option).hasClass('selected')) {
                            $(select).val('');
                            $(option).parents('.field').find('label').parent().find('span#value').html('');
                            $(option).parent().find('.selected').removeClass('selected');
                        } else {
                            $(select).val(optionValueId);
                            var $el = $(option).parents('.field').find('label').parent().find('span#value');
                            $el.html(' - ' + $(option).attr('option-label'));
                            if ($(option).attr('option-price') > 0) {
                                $el.html($el.html() + ' +' + priceUtils.formatPrice($(option).attr('option-price')));
                            }
                            $(option).parent().find('.selected').removeClass('selected');
                            $(option).addClass('selected');
                        }
                        $(select).trigger('change');
                        return;
                    }
                });
            }
        });

        return $.mage.mageworxOptionSwatch;
    }
);
