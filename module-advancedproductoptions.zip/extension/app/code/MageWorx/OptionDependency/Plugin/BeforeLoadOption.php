<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace MageWorx\OptionDependency\Plugin;

use \MageWorx\OptionDependency\Model\ResourceModel\CollectionUpdaterFactory;

/**
 * Class BeforeLoad. Replace option fields data to product attributes selected in setting.
 * This class are used when Option Value Collection are loading.
 */
class BeforeLoadOption
{
    protected $collectionUpdaterFactory;

    /**
     * BeforeLoad constructor.
     *
     * @param ObjectManager $objectManager
     * @param Registry $registry
     */
    public function __construct(
        CollectionUpdaterFactory $collectionUpdaterFactory
    ) {
        $this->collectionUpdaterFactory = $collectionUpdaterFactory;
    }

    /**
     * @param \Magento\Catalog\Model\ResourceModel\Product\Option\Collection $collection
     * @param bool $printQuery
     * @param bool $logQuery
     * @return array
     */
    public function beforeLoad($collection, $printQuery = false, $logQuery = false)
    {
        $this->collectionUpdaterFactory->create($collection)->update();

        return [$printQuery, $logQuery];
    }
}
