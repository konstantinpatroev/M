/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
define([
    'jquery',
    'underscore',
    'jquery/ui'
], function ($, _) {
    'use strict';

    $.widget('mageworx.optionDependency', {
        options: {
            dataType: {
                option: 'option_id',
                value: 'option_type_id'
            },
            addToCartSelector: '#product_addtocart_form',
            options: []
        },

        /**
         * Triggers one time at first run (from base.js)
         * @param optionConfig
         * @param productConfig
         * @param base
         * @param self
         */
        firstRun: function firstRun(optionConfig, productConfig, base, self)
        {
            this.initOptions()
                .observeOptions()
                .toggleOptions();

            return this;
        },

        /**
         * Triggers each time when option is updated\changed (from the base.js)
         * @param option
         * @param optionConfig
         * @param productConfig
         * @param base
         */
        update: function update(option, optionConfig, productConfig, base)
        {

        },

        /**
         * We track when parent option value is selected
         * and run method to show his dependent options
         *
         * observe select, multiselect
         * observe checkbox, radio
         */
        observeOptions: function () {
            var self = this;

            if (_.isArray(window.apoData) !== true) {
                window.apoData = [];
            }

            $.each(this.options.options, function (index, option) {

                if (_.isArray(window.apoData[option.id]) === false) {
                    window.apoData[option.id] = [];
                }

                if ($.inArray(option.type, ['drop_down', 'multiple']) !== -1) {
                    var select = $('[option_id="' + option.id + '"] select');

                    select.change(function () {
                        if ($.inArray(option.type, ['drop_down']) !== -1) {
                            // For dropdown - for selected select options only
                            $('#' + select.attr('id') + ' option:selected').each(function () {
                                self.toggleSelect(this, option);
                            });
                        } else {
                            // For multiselect - for all select options
                            $('#' + select.attr('id') + ' option').each(function () {
                                self.toggleSelect(this, option);
                            });
                        }
                    }).change();
                } else {
                    $.each(option.values, function (index, value) {

                        // set observer onchange based on type
                        var field = $('[option_type_id="' + value.id + '"]');
                        var type = value.getOption().type;

                        // checkbox and radio
                        if ($.inArray(type, ['checkbox', 'radio']) !== -1) {
                            var element = field.children('input');
                            element.change(function () {

                                if ($.inArray(type, ['checkbox']) !== -1) {
                                    self.toggleOption(value);
                                } else {
                                    self.toggleRadio(value, option);
                                }
                            });
                        }
                    });
                }
            });

            return this;
        },

        toggleSelect: function (selectOption, option) {
            var self = this,
            valueId = $(selectOption).attr('option_type_id');

            // For --Please Select-- - toggle all early selected values
            if (typeof valueId === "undefined" && _.isArray(window.apoData[option.id])) {
                $.each(option.values, function (index, value) {

                    var index = window.apoData[option.id].indexOf(value.id);

                    if (index !== -1) {
                        window.apoData[option.id].splice(index, 1);
                        self.toggleOption(value);
                    }
                });
            }

            // For select "normal" value
            if (typeof valueId !== "undefined") {
                // Toggle unselected values
                if (_.isArray(window.apoData[option.id])) {
                    $.each(option.values, function (index, value) {

                        if (value.id !== valueId && window.apoData[option.id].indexOf(value.id) !== -1) {
                            self.toggleOption(value);
                            var index = window.apoData[option.id].indexOf(value.id);

                            if (index !== -1) {
                                window.apoData[option.id].splice(index, 1);
                            }
                        }
                    });
                }

                // Toggle selected values
                $.each(option.values, function (index, value) {

                    if (value.id === valueId) {
                        self.toggleOption(value);
                        window.apoData[option.id].push(valueId);
                    }
                });
            }
        },

        toggleRadio: function (valueSelected, option) {
            var self = this,
            valueId = valueSelected.id;

            if (typeof valueId === "undefined") {
                return;
            }
            // Toggle unselected value
            if (_.isArray(window.apoData[option.id])) {
                $.each(option.values, function (index, value) {

                    if (value.id !== valueId && window.apoData[option.id].indexOf(value.id) !== -1) {
                        self.toggleOption(value);
                        var index = window.apoData[option.id].indexOf(value.id);

                        if (index !== -1) {
                            window.apoData[option.id].splice(index, 1);
                        }
                    }
                });
            }

            // Toggle selected value
            self.toggleOption(valueSelected);
            window.apoData[option.id].push(valueId);
        },

        toggleOptions: function () {
            var self = this;

            // toggle options: show or hide dependencies, deselect if hide
            $.each(this.options.options, function (index, option) {
                $.each(option.values, function (index, value) {
                    value.toggle();
                });

                option.toggle();
            });

            return this;
        },

        toggleOption: function (object) {

            var self = this;

            var childDependencies = _.isUndefined(object.type) ? self.options.valueChildren : self.options.optionChildren;

            if ($.inArray(object.id, _.keys(childDependencies)) === -1) {
                return this;
            }

            var children = childDependencies[object.id];

            $.each(children, function (index, childId) {
                var valueObj = self.getOptionObject(childId);
                if (valueObj) {
                    valueObj.toggle();
                }
            });

            var selected = $('#product_addtocart_form').find(':selected');

            $.each(selected, function (index, element) {
                var valueObj = self.getOptionObject($(element).attr('option_type_id'));

                if (valueObj) {
                    valueObj.toggle();
                }
            });

            var checked = $('#product_addtocart_form').find(':checked');

            $.each(checked, function (index, element) {
                var valueObj = self.getOptionObject($(element).attr('option_type_id'));
                if (valueObj) {
                    valueObj.toggle();
                }
            });

            $.each(this.options.options, function (index, option) {
                option.toggle();
            });

            return this;
        },

        getOptionObject: function (id) {

            var object = '';
            $.each(this.options.options, function (index, option) {
                if (option.id == id) {
                    object = option;
                    return false;
                }
                $.each(option.values, function (index, value) {
                    if (value.id == id) {
                        object = value;
                        return false;
                    }
                });
            });

            return object;
        },

        initOptions: function () {
            var self = this,
            isValid,
            getType,
            toggle,
            reset;

            /**
             * check if option or value is valid:
             * if true - show,
             * false - hide.
             *
             * @param object
             * @returns {boolean}
             */
            isValid = function (object) {
                // init parent dependencies:
                // if object is option - use optionParents,
                // else - valueParents.
                var parentDependencies = _.isUndefined(object.type) ? self.options.valueParents : self.options.optionParents;

                // 1. If object not exist in parentDependencies then it is not dependent
                // and return true.
                if ($.inArray(object.id, _.keys(parentDependencies)) === -1) {
                    return true;
                }

                // 2. If any of parents are selected - return true
                var parentSelected = false;
                var parents = parentDependencies[object.id]; // parent values ids

                $.each(parents, function (index, parentId) {
                    var field = $('[option_type_id="'+parentId+'"]');
                    var type = object._getType(parentId);

                    // checkbox and radio
                    if ($.inArray(type, ['checkbox', 'radio']) !== -1) {
                        var element = field.children('input');

                        if (element.prop('checked')) {
                            parentSelected = true;
                        }
                    }

                    // drop-down and multiselect
                    if ($.inArray(type, ['drop_down', 'multiple']) !== -1) {
                        var elements = field.parent('select').find(':selected');

                        $.each(elements, function (index, element) {
                            if ($(element).attr('option_type_id') == parentId) {
                                parentSelected = true;
                            }
                        });
                    }

                    if (parentSelected) {
                        return true;
                    }
                });

                return parentSelected;
            };

            /**
             * Retrieve option type, by value id.
             * Used for detect parent dependent option type.
             *
             * @param valueId
             * @returns {string}
             */
            getType = function (valueId) { // return option type by value
                var type = '';

                $.each(self.options.options, function (index, option) {
                    $.each(option.values, function (index, value) {
                        if (valueId == value.id) {
                            type = value.getOption().type;
                            return;
                        }
                    });
                    if (type) {
                        return;
                    }
                });

                return type;
            };

            toggle = function (object) {
                var isOption = _.isUndefined(object.type) ? false : true,
                field = isOption ? $('[option_id="'+object.id+'"]') : $('[option_type_id="'+object.id+'"]'),
                isRequired = false;

                if (isOption && typeof self.options.optionRequiredConfig != 'undefined') {
                    isRequired = typeof self.options.optionRequiredConfig[object.id] != 'undefined' ?
                    self.options.optionRequiredConfig[object.id] :
                    false;
                }
                // toggle visibility
                if (object.isValid()) {
                    field.show();
                    if (isOption && isRequired) {
                        field.addClass('required');
                        field.find('input, select, textarea, .field').addClass('required');
                    }
                } else {
                    field.hide();
                    if (isOption && isRequired) {
                        field.removeClass('required');
                        field.find('input, select, textarea, .field').removeClass('required');
                    }
                }

                // reset element
                object.reset();

                return object;
            },

            reset = function (value) {
                var isOption = _.isUndefined(value.type) ? false : true;
                if (isOption) {
                    return this;
                }

                var field = $('[option_type_id="'+value.id+'"]');
                if (field.css('display') != 'none') {
                    return this;
                }

                var type = value.getOption().type;
                var element = null;

                // checkbox and radio
                if ($.inArray(type, ['checkbox', 'radio']) !== -1) {
                    element = field.children('input');

                    element.removeAttr('checked');
                    element.trigger('change');
                }

                // drop-down and multiselect
                if ($.inArray(type, ['drop_down', 'multiple']) !== -1) {
                    element = field.parent('select');

                    field.removeAttr('selected');
                    element.trigger('change');
                }

                // update product price
                var priceOptions = $(self.options.addToCartSelector).data('magePriceOptions');
                if (!_.isUndefined(priceOptions) && !_.isNull(element)) {
                    priceOptions._onOptionChanged({target: element});
                }

                return this;
            },

            $('[option_id]').each(function (index, option) {

                var values = [];
                var optionObj = {}; // create emty option object to transfer the link to it to value

                $(option).find('[option_type_id]').each(function (index, value) {

                    var valueObj = {
                        id: $(value).attr('option_type_id'),
                        isValid: function () {
                            return isValid(this);
                        },
                        _getType: function (valueId) { // return option type by value
                            return getType(valueId);
                        },
                        toggle: function () {
                            return toggle(this);
                        },
                        reset: function () {
                            return reset(this);
                        },
                        getOption: function () {
                            return optionObj;
                        }
                    };

                    values.push(valueObj);
                });

                optionObj = {
                    id: $(option).attr('option_id'),
                    type: self.options.optionTypes[$(option).attr('option_id')],
                    values: values,
                    isValid: function () { // option is valid if it is not SELECT type or if any of values is valid
                        // 1. check if not SELECT option type
                        // If not SELECT - get parent values and validate
                        if (_.isEmpty(this.values)) {
                            return isValid(this);
                        }

                        // 2. If option is SELECT type - check if any of his values is valid
                        var valuesIsValid = false;
                        $.each(this.values, function (index, value) {
                            if (value.isValid()) {
                                valuesIsValid = true;
                                return;
                            }
                        });

                        return valuesIsValid;
                    },
                    _getType: function (valueId) { // return option type by value
                        return getType(valueId);
                    },
                    reset: function () {
                        return reset(this);
                    },
                    toggle: function () {
                        return toggle(this);
                    }
                };

                self.options.options.push(optionObj);
            });

            return this;
        }
    });

    return $.mageworx.optionDependency;
});